const CopyWebpackPlugin = require('copy-webpack-plugin')
const path = require('path')
const GenerateAssetPlugin = require('generate-asset-webpack-plugin'); 
const createServerConfig = function(compilation){
  let cfgJson = require('./config.js')
  return JSON.stringify(cfgJson);
}

module.exports = {
  configureWebpack: {
    plugins: [
      // new CopyWebpackPlugin([{
      //   from: path.resolve(__dirname, './config.js'),
      //   to: './'
      // }])
      new GenerateAssetPlugin({
        filename: 'config.json',
        fn: (compilation, cb) => {
          cb(null, createServerConfig(compilation));
        },
        extraFiles: []
      })
    ]
  },
  publicPath: './'
}