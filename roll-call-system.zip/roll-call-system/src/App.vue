<template>
  <div id="app">
    <div class="roll_call_system">
      <div class="seleted_con">
        <div class="title" v-show="!running && !seletedName.length">{{title}}</div>
        <div class="seleted_tip" v-show="!running && seletedName.length">{{seletedTip}}</div>
        <div class="seleted_name">{{seletedName}}</div>
      </div>
      <table class="student_table">
        <tbody>
          <tr v-for="(value, key, index) in allStudents" :key='key'>
            <td>{{key}}</td>
            <td v-for='(col, ind) in value' :key='ind' :class="{'student_name1': col != '' && index % 2 == 0, 'student_name2': col != '' && index % 2 == 1, 'seleted': col != '' && seletedName == col, 'del': col != '' && seletedStudents.includes(col) }">
            {{col}}</td>
          </tr>
        </tbody>
      </table>
      <div class="button_con">
        <el-button @click="handleButton" type="primary">{{buttonText}}</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'app',
  data() {
    return {
      allStudents: {},
      sort: [],
      allStudentsName: [],
      seletedTip: '',
      seletedName: '',
      random: 0,
      setInterval: null,
      buttonText: '',
      running: false,
      delSelected: false,
      seletedStudents: [],
      hoodoo: [],
      title: ''
    }
  },
  async mounted() {
    await new Promise((resolve)=>{
      axios.get('config.json').then(res => {
        window.config = res.data
        this.allStudents = window.config.所有学生
        this.sort = window.config.排列方式
        this.seletedTip = window.config.选中提示语
        this.buttonText = window.config.按钮开始文字
        this.delSelected = window.config.是否去除被点学生
        this.hoodoo = window.config.指定选择
        this.title = window.config.系统名称
        resolve()
      }).catch((error) => {
        throw error;
      })
    })
    for (let key in this.allStudents) {
      this.allStudentsName = this.allStudentsName.concat(this.allStudents[key])
    }
    this.sort.splice(this.sort.length - 1, 1)
    this.sort.forEach((val, key) => {
      this.sort[key] = val + (this.sort[key - 1] || 0)
    })
    this._.forEachRight(this.sort, (val) => {
      for (let key in this.allStudents) {
        this.allStudents[key].splice(val, 0, '')
      }
    })
    document.onkeydown =  (event) => {
      var e = event || window.event;
      if (e && e.keyCode == 13) { 
          this.handleButton()
      }
    }; 
  },
  methods: {
    handleButton() {
      if (!this.running) {
        if (this.delSelected) {
          this.seletedStudents.push(this.seletedName)
          this.allStudentsName.splice(this.random, 1)
        }
        this.running = true
        this.buttonText = window.config.按钮结束文字
        this.setInterval = setInterval(()=>{
          this.random = Math.floor(Math.random()*this.allStudentsName.length);
          this.seletedName = this.allStudentsName[this.random]
        }, window.config.选择间隔)
      } else {
        if (this.hoodoo.length && !this.delSelected) {
          this.random = Math.floor(Math.random()*this.hoodoo.length);
          this.seletedName = this.hoodoo[this.random]
        }
        this.running = false
        this.buttonText = window.config.按钮开始文字
        clearInterval(this.setInterval)
      }
    }
  }
}
</script>

<style lang="scss">
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
  .roll_call_system {
    .seleted_con {
      height: 160px;
      padding-bottom: 60px;
      position: relative;
      .title,.seleted_tip {
        font-size: 40px;
        color: #666
      }
      .title {
        font-size: 60px;
      }
      .seleted_name {
        width: 100%;
        text-algin: center;
        font-size: 80px;
        font-weight: 600;
        position: absolute;
        top: 52px;
      }
    }
    .student_table {
      border-collapse:collapse;
      margin: 0 auto;
      td {
        height: 40px;
        width: 80px;
      }
      .student_name1 {
        &:nth-child(2n) {
          background: #ededed
        }
        &:nth-child(2n-1) {
          background: #e2e2e2
        }
      }
      .student_name2 {
        &:nth-child(2n) {
          background: #e2e2e2
        }
        &:nth-child(2n-1) {
          background: #ededed
        }
      }
      .seleted {
        background: #1874a0 !important;
        color: white
      }
      .del {
        opacity: 0.4;
        background: #1874a0 !important;
        color: white
      }
    }
    .button_con {
      padding-top: 100px;
      .el-button {
        width: 260px;
        height: 50px;
        background: #1874a0;
        font-size: 18px
      }
    }
  }
}
</style>
